<div class="wrap">
    <div class="container">
        <?php erios_render_footer(); ?>
    </div>
</div>