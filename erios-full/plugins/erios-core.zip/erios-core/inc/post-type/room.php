<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class OSF_Custom_Post_Type_Room
 */
class OSF_Custom_Post_Type_Room extends OSF_Custom_Post_Type_Abstract {
    public $post_type = 'osf_room';
    public $taxonomy  = 'osf_room_cat';

    static $instance;

    public static function getInstance() {
        if (!isset(self::$instance) && !(self::$instance instanceof OSF_Custom_Post_Type_Room)) {
            self::$instance = new OSF_Custom_Post_Type_Room();
        }

        return self::$instance;
    }

    /**
     * @return void
     */
    public function create_post_type() {

        $labels = array(
            'name'               => __('Rooms', 'erios-core'),
            'singular_name'      => __('Room', 'erios-core'),
            'add_new'            => __('Add New Room', 'erios-core'),
            'add_new_item'       => __('Add New Room', 'erios-core'),
            'edit_item'          => __('Edit Room', 'erios-core'),
            'new_item'           => __('New Room', 'erios-core'),
            'view_item'          => __('View Room', 'erios-core'),
            'search_items'       => __('Search Rooms', 'erios-core'),
            'not_found'          => __('No Rooms found', 'erios-core'),
            'not_found_in_trash' => __('No Rooms found in Trash', 'erios-core'),
            'parent_item_colon'  => __('Parent Room:', 'erios-core'),
            'menu_name'          => __('Rooms', 'erios-core'),
        );

        $labels     = apply_filters('osf_postype_room_labels', $labels);
        $slug_field = osf_get_option('room_settings', 'slug_room', 'room');

        register_post_type($this->post_type,
            array(
                'labels'        => $labels,
                'supports'      => array('title', 'editor', 'excerpt', 'thumbnail'),
                'public'        => true,
                'has_archive'   => true,
                'rewrite'       => array('slug' => $slug_field),
                'menu_position' => 5,
                'categories'    => array(),
                'menu_icon'     => $this->get_icon(__FILE__)
            )
        );
    }

    /**
     * @return void
     */
    public function create_taxonomy() {
        $labels         = array(
            'name'              => __('Categories', 'erios-core'),
            'singular_name'     => __('Category', 'erios-core'),
            'search_items'      => __('Search Category', 'erios-core'),
            'all_items'         => __('All Categories', 'erios-core'),
            'parent_item'       => __('Parent Category', 'erios-core'),
            'parent_item_colon' => __('Parent Category:', 'erios-core'),
            'edit_item'         => __('Edit Category', 'erios-core'),
            'update_item'       => __('Update Category', 'erios-core'),
            'add_new_item'      => __('Add New Category', 'erios-core'),
            'new_item_name'     => __('New Category Name', 'erios-core'),
            'menu_name'         => __('Categories', 'erios-core'),
        );
        $labels         = apply_filters('osf_postype_room_cat_labels', $labels);
        $slug_cat_field = osf_get_option('room_settings', 'slug_category_room', 'category-room');
        $args           = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'show_in_nav_menus' => true,
            'rewrite'           => array('slug' => $slug_cat_field)
        );
        // Now register the taxonomy
        register_taxonomy($this->taxonomy, array($this->post_type), $args);
    }

    /**
     * @param $classes
     *
     * @return array
     */
    public function body_class($classes) {
        if (is_post_type_archive($this->post_type) || is_tax($this->taxonomy)) {
            $classes[] = 'opal-content-layout-' . get_theme_mod('osf_room_archive_layout', '1c');
        } else if (is_singular($this->post_type)) {
            $classes[] = 'opal-content-layout-' . get_theme_mod('osf_room_single_layout', '2cr');
        }

        return $classes;
    }

    /**
     * @param array $arg
     *
     * @return WP_Query
     */
    public function create_query($per_page = -1, $taxonomies = array()) {
        $args = array(
            'post_type'      => $this->post_type,
            'posts_per_page' => $per_page,
            'post_status'    => 'publish',
        );
        if (!empty($taxonomies)) {
            $args ['tax_query'] = array(
                'taxonomy' => $this->taxonomy,
                'field'    => 'slug',
                'terms'    => $taxonomies
            );
        }

        return new WP_Query($args);
    }

    public function customize_register($wp_customize) {

        $wp_customize->add_panel('osf_room', array(
            'title'      => __('Room', 'erios-core'),
            'capability' => 'edit_theme_options',
            'priority'   => 1,
        ));

        //Room Archive config
        $wp_customize->add_section('osf_room_archive', array(
            'title'      => __('Archive', 'erios-core'),
            'capability' => 'edit_theme_options',
            'panel'      => 'osf_room',
            'priority'   => 1,
        ));

        // =========================================
        // Select Layout
        // =========================================

        $wp_customize->add_control(new OSF_Customize_Control_Image_Select($wp_customize, 'osf_room_archive_layout', array(
            'section' => 'osf_room_archive',
            'label'   => __('Select Layout', 'erios-core'),
            'choices' => $this->options,
        )));

        $wp_customize->add_setting('osf_room_archive_column', array(
            'default'           => '3',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('osf_room_archive_column', array(
            'section' => 'osf_room_archive',
            'label'   => __('Columns', 'erios-core'),
            'type'    => 'select',
            'choices' => array(
                '1' => __('1 Column', 'erios-core'),
                '2' => __('2 Columns', 'erios-core'),
                '3' => __('3 Columns', 'erios-core'),
                '4' => __('4 Columns', 'erios-core'),
            ),
        ));

        if (class_exists('OSF_Customize_Control_Button_Group')) {
            $wp_customize->add_setting('osf_room_archive_style', array(
                'default'           => '1',
                'sanitize_callback' => 'sanitize_text_field',
            ));
            $wp_customize->add_control(new OSF_Customize_Control_Button_Group($wp_customize, 'osf_room_archive_style', array(
                'section' => 'osf_room_archive',
                'label'   => __('Select Style', 'erios-core'),
                'default' => '1',
                'choices' => array(
                    '1' => __('Style 1', 'erios-core'),
                    '2' => __('Style 2', 'erios-core'),
                ),
            )));
        }

    }

    public function create_meta_box() {
        $prefix = 'osf_';

        $cmb2_fields = apply_filters('room_fields', array(
            'id'            => $prefix . 'room_setting',
            'title'         => __('Room Infomation', 'erios-core'),
            'object_types'  => array('osf_room'),
            'vertical_tabs' => true,
            'tabs'          => array(
                array(
                    'id'     => 'osf_room_tabs_1',
                    'title'  => __('General', 'erios-core'),
                    'fields' => array(
                        $prefix . 'currency_symbol',
                        $prefix . 'room_price',
                        $prefix . 'room_price_period',
                        $prefix . 'room_gallery',
                        $prefix . 'room_video',
                        $prefix . 'room_link',
                    ),
                ),
                array(
                    'id'     => 'osf_room_tabs_2',
                    'title'  => __('Feature', 'erios-core'),
                    'fields' => array(
                        $prefix . 'room_feature',
                    ),
                ),
            )
        ));

        $cmb2 = new_cmb2_box($cmb2_fields);

        $cmb2->add_field(array(
            'name'             => __('Currency Symbol', 'erios-core'),
            'id'               => $prefix . 'currency_symbol',
            'type'             => 'select',
            'show_option_none' => false,
            'default'          => 'dollar',
            'options'          => apply_filters('osf_currency_symbol_filters', array(
                'dollar'       => '&#36; ' . _x('Dollar', 'Currency Symbol', 'erios-core'),
                'euro'         => '&#128; ' . _x('Euro', 'Currency Symbol', 'erios-core'),
                'baht'         => '&#3647; ' . _x('Baht', 'Currency Symbol', 'erios-core'),
                'franc'        => '&#8355; ' . _x('Franc', 'Currency Symbol', 'erios-core'),
                'guilder'      => '&fnof; ' . _x('Guilder', 'Currency Symbol', 'erios-core'),
                'krona'        => 'kr ' . _x('Krona', 'Currency Symbol', 'erios-core'),
                'lira'         => '&#8356; ' . _x('Lira', 'Currency Symbol', 'erios-core'),
                'peseta'       => '&#8359 ' . _x('Peseta', 'Currency Symbol', 'erios-core'),
                'peso'         => '&#8369; ' . _x('Peso', 'Currency Symbol', 'erios-core'),
                'pound'        => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'erios-core'),
                'real'         => 'R$ ' . _x('Real', 'Currency Symbol', 'erios-core'),
                'ruble'        => '&#8381; ' . _x('Ruble', 'Currency Symbol', 'erios-core'),
                'rupee'        => '&#8360; ' . _x('Rupee', 'Currency Symbol', 'erios-core'),
                'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'Currency Symbol', 'erios-core'),
                'shekel'       => '&#8362; ' . _x('Shekel', 'Currency Symbol', 'erios-core'),
                'yen'          => '&#165; ' . _x('Yen/Yuan', 'Currency Symbol', 'erios-core'),
                'won'          => '&#8361; ' . _x('Won', 'Currency Symbol', 'erios-core'),
            )),
        ));

        $cmb2->add_field(array(
            'name'         => __('Price', 'erios-core'),
            'id'           => $prefix . 'room_price',
            'type'         => 'text_money',
            'before_field' => ' ', // Replaces default '$'
        ));

        $cmb2->add_field(array(
            'name' => __('Period', 'erios-core'),
            'id'   => $prefix . 'room_price_period',
            'type' => 'text',
        ));

        $cmb2->add_field(array(
            'name'       => __('Gallery', 'erios-core'),
            'id'         => $prefix . 'room_gallery',
            'type'       => 'file_list',
            'query_args' => array(
                'type' => array(
                    'image/gif',
                    'image/jpeg',
                    'image/png',
                ),
            ),
        ));

        $group_field_id = $cmb2->add_field(array(
            'id'      => $prefix . 'room_feature',
            'type'    => 'group',
            'options' => array(
                'group_title'   => __('Feature {#}', 'erios-core'),
                'add_button'    => __('Add Another Feature', 'erios-core'),
                'remove_button' => __('Remove Feature', 'erios-core'),
                'sortable'      => true,

            ),
        ));

        $cmb2->add_group_field( $group_field_id, array(
            'name'        => __( 'Icon', 'erios-core' ),
            'id'          => 'icon',
            'description' => __( 'Link icons library "http://demo2.wpopal.com/erios/icons/"', 'erios-core' ),
            'type'        => 'text',
        ) );

        $cmb2->add_group_field($group_field_id, array(
            'name' => __('Description', 'erios-core'),
            'id'   => 'description',
            'type' => 'text',
        ));

        $cmb2->add_field(array(
            'name' => __('Link Book', 'erios-core'),
            'id'   => $prefix . 'room_link',
            'type' => 'text_url',
        ));

    }

    /**
     * @return array|int|WP_Error
     */
    public function get_terms() {
        return get_terms(array($this->taxonomy));
    }

    public function get_term_room($post_id) {
        $terms  = get_the_terms($post_id, $this->taxonomy);
        $output = '';
        if (!is_wp_error($terms) && is_array($terms)) {
            foreach ($terms as $key => $term) {
                $term_link = get_term_link($term);
                if (is_wp_error($term_link)) {
                    continue;
                }
                $output .= '<a href="' . esc_url($term_link) . '">' . $term->name . '</a>';
                if ($key < count($terms) - 1) {
                    $output .= ', ';
                }
            }

        }

        return $output;
    }

    public function widgets_init() {
        register_sidebar(array(
            'name'          => esc_html__('Room Sidebar', 'erios-core'),
            'id'            => 'sidebar-room',
            'description'   => esc_html__('Add widgets here to appear in your Room.', 'erios-core'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));
    }

    public function get_currency_symbol($symbol_name) {

        $symbols = apply_filters('osf_symbols', [
            'dollar'       => '&#36;',
            'euro'         => '&#128;',
            'franc'        => '&#8355;',
            'pound'        => '&#163;',
            'ruble'        => '&#8381;',
            'shekel'       => '&#8362;',
            'baht'         => '&#3647;',
            'yen'          => '&#165;',
            'won'          => '&#8361;',
            'guilder'      => '&fnof;',
            'peso'         => '&#8369;',
            'peseta'       => '&#8359',
            'lira'         => '&#8356;',
            'rupee'        => '&#8360;',
            'indian_rupee' => '&#8377;',
            'real'         => 'R$',
            'krona'        => 'kr',
        ]);

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : $symbol_name;
    }

    function related_room($relate_count = 3, $posttype = 'osf_room', $taxonomy = 'osf_room_cat') {

        $terms = get_the_terms(get_the_ID(), $taxonomy);
        $termids = array();

        if ($terms) {
            foreach ($terms as $term) {
                $termids[] = $term->term_id;
            }
        }

        $args = array(
            'post_type'      => $posttype,
            'posts_per_page' => $relate_count,
            'post__not_in'   => array(get_the_ID()),
            'tax_query'      => array(
                'relation' => 'AND',
                array(
                    'taxonomy' => $taxonomy,
                    'field'    => 'id',
                    'terms'    => $termids,
                    'operator' => 'IN'
                )
            )
        );

        $related = new WP_Query($args);

        if ($related->have_posts()) {
            echo '<div class="related-room">';
            echo '<h2 class="related-heading">' . esc_html__('Discover More Rooms', 'erios-core') . '</h2>';
            echo '<div class="row elementor-room-style-1" data-elementor-columns="3">';
            while ($related->have_posts()) : $related->the_post();
                ?>
                <div class="column-item">
                    <?php get_template_part('template-parts/room/content'); ?>
                </div>
            <?php
            endwhile;
            echo '</div>';
            echo '</div>';

            wp_reset_postdata();
        }


    }
}

//OSF_Custom_Post_Type_Room::getInstance();